Library Reference
=================

.. toctree::
   :maxdepth: 1

   models
   metrics
   utils