Tutorials and Examples
======================

.. toctree::
   :maxdepth: 2
   
   notebooks/howtouse.rst
   notebooks/sparse.ipynb
   notebooks/dense.ipynb
   notebooks/nowcasting.ipynb