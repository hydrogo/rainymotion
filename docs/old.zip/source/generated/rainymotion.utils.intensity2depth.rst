rainymotion.utils.intensity2depth
=================================

.. currentmodule:: rainymotion.utils

.. autofunction:: intensity2depth