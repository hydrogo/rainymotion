rainymotion.utils.depth2intensity
=================================

.. currentmodule:: rainymotion.utils

.. autofunction:: depth2intensity