rainymotion.utils.RYScaler
==========================

.. currentmodule:: rainymotion.utils

.. autofunction:: RYScaler